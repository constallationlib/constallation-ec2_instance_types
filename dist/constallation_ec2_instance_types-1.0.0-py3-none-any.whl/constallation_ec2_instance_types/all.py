from general_purpose import *
from compute_optimized import *
from memory_optimized import *
from accelerated_computing import *
from storage_optimized import *
from hpc_optimized import *